#ifndef SCENE_VICTORY_H
#define SCENE_VICTORY_H
#include "game.h"
#include "utility.h"
#include "shared.h"

Scene scene_victory_create(void);


#endif
