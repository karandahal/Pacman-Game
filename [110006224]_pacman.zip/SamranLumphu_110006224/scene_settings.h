#ifndef SCENE_SETTINGS_H
#define SCENE_SETTINGS_H
#include "game.h"
#include "utility.h"
#include "shared.h"

Scene scene_settings_create(void);
Scene scene_lose_create(void);
#endif
